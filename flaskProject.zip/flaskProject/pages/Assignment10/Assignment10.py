from flask import Flask, redirect, url_for, render_template, Blueprint
from flask import request
from flask import session
import mysql.connector

Assignment10 = Blueprint('Assignment10', __name__,
                  static_folder='static',
                  static_url_path='/pages/Assignment10',
                  template_folder='templates')


def interact_db(query, query_type: str):
    return_value = False
    connection = mysql.connector.connect(host='localhost',
                                         user='root',
                                         password='vixeriA1',
                                         database='Assignment10')
    cursor = connection.cursor(named_Tuple=True)
    cursor.execute(query)

    if query_type == 'commit':
        connection.commit()
        return_value = True

    if query_type == 'fetch':
        query_result = cursor.fetchall()
        return_value = query_result

        connection.close()
        cursor.close()
        return return_value


@Assignment10.route('/assignment10')
def assignment10():
    query = "select * from users"
    query_result = interact_db(query, query_type='fetch')
    print(query_result)
    return render_template('Assignment10.html', users=query_result)



@Assignment10.route('/insert_funq', methods=['GET','POST'])
def insert_funq():
    if request.method == 'POST':
        id = request.form['id']
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        query = "Insert into users(id,first_name,list_name ,email) values ('%s','%s','%s','%s') " % (id,first_name, last_name, email)
        interact_db(query=query, query_type='commit')
        return redirect('/assignment10')
    return 'an Error occurred'


@Assignment10.route('/delete_funq', methods=['GET', 'POST'])
def delete_funq():
    if request.method == 'GET':
        user_id = request.args['id']
        query = "DELETE FROM users WHERE id='%s';" %user_id
        return redirect('/assignment10')
    return 'user was deleted'

@Assignment10.route('/update_funq', methods=['GET','POST'])
def update_funq():
    if request.method == 'POST':
        id = request.form['id']
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        query1 = "UPDATE users SET first_name=('%s')  WHERE id=(%s)" % (first_name,id)
        query2 = "UPDATE users SET last_name=('%s')  WHERE id=(%s)" % (last_name, id)
        query3 = "UPDATE users SET email=('%s')  WHERE id=(%s)" % (email, id)
        interact_db(query=query1, query_type='commit')
        interact_db(query=query2, query_type='commit')
        interact_db(query=query3, query_type='commit')
        return redirect('/assignment10')
    return 'an Error occurred'



